package edu.buaa.crawler;

import java.io.File;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class SinaNewsDataRead {

	// 核心配置类
	// 需要导入的支持包是 org.apache.hadoop 包下的支持
	private static Configuration conf = new Configuration();
	// HDFS文件系统的支持类
	private static FileSystem fs;
	// 表示要操作的HDFS中的文件或文件夹路径
	private static Path path;

	private static int count = 0;

	// 判断文件路径和文件名是否符合要求的正则表达式
	private static final String FILE_NAME_REG = ".*/\\d{4}-\\d{2}-\\d{2}/.*\\d+\\.shtml";

	// 保存的文件夹的主目录
	private static final String SAVE_PATH = "hdfs://localhost:9000/sina_news_input/";

	public static void main(String[] args) throws Exception {
		// getFileData(
		//		"/Users/kkb/Documents/heritrix-1.12.1/jobs/sina_news_new-20171026104442286/mirror/sky.news.sina.com.cn/cxzx/2016-05-09/doc-ifxryhhh1805686.shtml");
		parseAllFiles(new File("/Users/kkb/Documents/heritrix-1.12.1/jobs/sina_news_new-20171026104442286/mirror/"));
	
	}

	// 遍历某个目录下的所有文件和文件夹，判断是否是需要进行内容处理的文件
	// 如果是就进行处理，如果不是继续遍历，直到所有的文件夹都处理完成。
	public static void parseAllFiles(File f) {
		// 判断这是一个文件还是一个文件夹
		if (f.isDirectory()) {
			// 文件夹
			// 列出这个文件夹下的所有文件或文件夹
			File[] allFile = f.listFiles();
			// 对这些文件或文件夹同样也进行解析处理
			for (File temp:allFile) {
				parseAllFiles(temp);
			}
		} else {
			// 文件
			// 判断文件是否满足我们的要求，是否需要提取出来
			if (f.getAbsolutePath().matches(FILE_NAME_REG)) {
				try {
					getFileData(f.getAbsolutePath());
					System.out.println("已经处理完成文件数量：" + ++count);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	// 读取某一个目录下的某一个文件，来进行内容的提取
	public static void getFileData(String filePath) throws Exception {
		// 通过JSoup来提取文件的内容
		Document doc = Jsoup.parse(new File(filePath), "UTF-8");

		// 取得里面的title和desc
		String title = doc.title();

		Element descEl = doc.getElementsByAttributeValue("name", "description").get(0);
		String desc = descEl.attr("content");

		// 将数据保存到HDFS里
		// 生成一个要保存的文件名
		String fileName = System.currentTimeMillis() + ".txt";
		// 建立要保存的HDFS路径
		path = new Path(SAVE_PATH + fileName);
		// 根据路径找到HDFS文件系统
		if (fs == null) {
			fs = path.getFileSystem(conf);
		}
		// 通过文件系统对象来建立一个输出流，保存文件内容
		FSDataOutputStream os = fs.create(path);

		// 将内容写出到HDFS中
		os.writeUTF(title + "\r\n" + desc);

		os.close();

	}

}
