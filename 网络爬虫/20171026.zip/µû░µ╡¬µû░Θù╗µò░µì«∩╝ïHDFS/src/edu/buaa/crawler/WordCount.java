package edu.buaa.crawler;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import jeasy.analysis.MMAnalyzer;

public class WordCount {

	public static class TokenizerMapper extends Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();

		private static MMAnalyzer mm = new MMAnalyzer();

		private static Set<String> allNoWord = new HashSet<String>();
		static {
			allNoWord.add("新浪");
			allNoWord.add("新浪网");
			allNoWord.add("nbsp");
			allNoWord.add("新闻");
			allNoWord.add("标题");
		}

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			// 分词处理
			String result = mm.segment(value.toString(), "|");
			System.out.println(result);
			String[] strs = result.split("\\|");
			for (String str : strs) {
				if (str.length() > 1 && !allNoWord.contains(str)) {
					word.set(str);
					context.write(word, one);
				}
			}
		}
	}

	public static class IntSumReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "word count");
		job.setJarByClass(WordCount.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path("hdfs://localhost:9000/sina_news_input"));
		FileOutputFormat.setOutputPath(job, new Path("hdfs://localhost:9000/sina_news_output"));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
