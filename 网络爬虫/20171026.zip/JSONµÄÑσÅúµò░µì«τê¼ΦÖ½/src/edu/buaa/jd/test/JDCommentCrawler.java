package edu.buaa.jd.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class JDCommentCrawler {

	public static void main(String[] args) throws Exception {

	}

	public static void parseComments(String productId) throws Exception {
		String baseUrl = "https://club.jd.com/comment/productPageComments.action?score=0&sortType=5&isShadowSku=0&fold=1&pageSize=10&productId="
				+ productId + "&page=";

		PrintWriter writer = new PrintWriter(
				new File("/Users/kkb/Documents/jd_data/" + productId + ".txt"));

		// 循环100页的评论数据
		for (int i = 0; i < 100; i++) {
			URL url = new URL(baseUrl + i);
			URLConnection conn = url.openConnection();
			InputStream is = conn.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "GBK"));
			StringBuilder builder = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
			reader.close();

			// 有了JSON数据内容，就需要解析，并将里面的数据内容提取出来。
			// 这里使用 fastjson的库，来完成解析功能
			JSONObject obj = JSON.parseObject(builder.toString());
			JSONArray commentsArray = obj.getJSONArray("comments");
			for (int j = 0; j < commentsArray.size(); j++) {
				JSONObject temp = commentsArray.getJSONObject(j);
				writer.println(temp.getString("content"));
			}
		}
		writer.close();
		System.out.println("成功保存商品：" + productId);
	}

}
