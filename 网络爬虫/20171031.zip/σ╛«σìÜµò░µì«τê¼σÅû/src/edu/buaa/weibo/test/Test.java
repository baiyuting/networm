package edu.buaa.weibo.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "/Users/kkb/Downloads/chromedriver");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 30);

		driver.get("http://weibo.com");

		// 需要等待
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("loginname")));

		// 定位用户名和密码的输入框
		WebElement usernameEl = driver.findElement(By.id("loginname"));
		WebElement passwordEl = driver.findElement(By.name("password"));
		// 输入用户名和密码
		usernameEl.sendKeys("mavisliky@sohu.com");
		passwordEl.sendKeys("buaa1234");

		// 找到提交按钮
		WebElement submitBtn = driver.findElement(By.cssSelector("a[node-type=submitBtn]"));
		submitBtn.click();

		// 当登录成功后，可以访问另外一个关心的页面，来进行数据的提取。
		driver.get("https://weibo.com/1806128454/FsA2xjNEM?refer_flag=1001030106_&type=comment");

	}

}
