package edu.buaa.baidu.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import jeasy.analysis.MMAnalyzer;

public class BaiduTest {

	public static void main(String[] args) throws Exception {

		Class.forName("org.gjt.mm.mysql.Driver");
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/sina_news_data?useUnicode=true&characterEncoding=UTF-8", "root", "root");

		// 配置系统变量
		// 前面的key根据浏览器的不同，需要调整中间的值，改为ie或firefox
		// 后面的value就是浏览器驱动的位置和文件名
		System.setProperty("webdriver.chrome.driver", "/Users/kkb/Downloads/chromedriver");
		// 就可以开始建立一个浏览器对象，来模拟真实浏览器的操作了
		WebDriver driver = new ChromeDriver();
		// 准备一个执行javascript的代码对象
		JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
		// 设置要访问的地址
		driver.get("http://www.baidu.com");
		// 建立一个等待时间的处理类
		WebDriverWait wait = new WebDriverWait(driver, 30);

		// 找到页面的文本框和提交按钮
		// 这里的类型是WebElement
		// 优先通过id定位到这个元素
		WebElement inputEl = driver.findElement(By.id("kw"));
		// 向其中输入内容
		inputEl.sendKeys("java");
		// 通过id定位
		WebElement submitEl = driver.findElement(By.id("su"));
		// 点
		submitEl.click();
		// Thread.sleep(1000);
		// 这里需要等待页面的查询结果出现，再进行 数据的提取 。
		// 查询条件需要通过ExpectedConditions来进行设置
		// 这里设置的是当页面元素出现时（存在时）进行提取。
		StringBuilder builder = new StringBuilder();

		for (int i = 0; i < 10; i++) {
			// 判断head的class值
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("_mask")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("h3")));
			// 根据标签名称，将结果提取出来
			List<WebElement> allTitle = driver.findElements(By.tagName("h3"));

			// 循环取得里面的文字内容
			for (WebElement titleEl : allTitle) {
				builder.append(titleEl.getText());
			}
			// 滚动到屏幕的最下面
			// 向页面发送一段JavaScript代码，让页面自动进行滚动操作
			jsDriver.executeScript("window.scrollTo(0,document.body.scrollHeight);");
			// 找到下一页 按钮
			WebElement nextPageBtn = driver.findElement(By.linkText("下一页>"));
			// 点击
			nextPageBtn.click();
		}

		String sql = "INSERT INTO sina_news (keywords,counts) VALUES (?,?)";
		MMAnalyzer mm = new MMAnalyzer();
		// 进行分词操作
		String[] strs = mm.segment(builder.toString(), "|").split("\\|");
		Map<String, Integer> allKw = new HashMap<String, Integer>();
		for (String str : strs) {
			if (allKw.containsKey(str)) {
				allKw.put(str, allKw.get(str) + 1);
			} else {
				allKw.put(str, 1);
			}
		}

		PreparedStatement pst = null;
		Set<String> allKeys = allKw.keySet();
		for (String key:allKeys) {
			int value = allKw.get(key);
			pst = conn.prepareStatement(sql);
			pst.setString(1, key);
			pst.setInt(2, value);
			pst.executeUpdate();
			pst.close();
		}
		conn.close();

	}
}
