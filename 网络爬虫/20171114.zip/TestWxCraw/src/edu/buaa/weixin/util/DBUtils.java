package edu.buaa.weixin.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import edu.buaa.weixin.vo.Article;

public class DBUtils {

	private static Connection conn;

	static {
		try {
			// 初始化数据库连接对象
			Class.forName("org.gjt.mm.mysql.Driver");
			// 根据数据库的位置和用户名密码，来链接数据库
			// 注意 Connection 的包 使用 java.sql.包
			conn = DriverManager
					.getConnection(
							"jdbc:mysql://localhost:3306/wxdata?useUnicode=true&characterEncoding=UTF-8",
							"root", "root");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 保存公众号数据的方法
	public static void insertWeixin(String bizid) throws Exception {
		// 先要判断这个公众号是否被抓去过，在weixin表中是否已经有了这条数据
		String sql = "SELECT id FROM weixin WHERE biz = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, bizid);
		ResultSet rs = pst.executeQuery();
		if (!rs.next()) {
			// 数据库中没有这条数据，需要进行保存操作
			sql = "INSERT INTO weixin (biz,get_date) VALUES (?,?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, bizid);
			// 设置当前的系统时间
			pst.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
			pst.executeUpdate();

		}
		rs.close();
		pst.close();
	}

	/**
	 * 保存文章的方法，
	 * 
	 * @param article
	 *            文章对象
	 * @return 是否有重复的内容
	 * @throws Exception
	 */
	public static boolean insertArticle(Article article) throws Exception {
		// 先从数据库里查询一下数据库中到底有没有这条数据
		String sql = "SELECT id FROM article WHERE content_url = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, article.getContentUrl());
		// 取得结果，判断是否有重复数据
		boolean flag = true;
		ResultSet rs = pst.executeQuery();
		if (!rs.next()) {
			flag = false;
			// 没有重复
			// 需要进行数据的保存
			sql = "INSERT INTO article (biz,title,digest,pub_date,content_url,source_url,"
					+ "cover,is_multi,author) VALUES (?,?,?,?,?,?,?,?,?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, article.getBiz());
			pst.setString(2, article.getTitle());
			pst.setString(3, article.getDigest());
			pst.setTimestamp(4, new Timestamp(article.getPubDate().getTime()));
			pst.setString(5, article.getContentUrl());
			pst.setString(6, article.getSourceUrl());
			pst.setString(7, article.getCover());
			pst.setInt(8, article.getIsMulti());
			pst.setString(9, article.getAuthor());
			pst.executeUpdate();
		}
		rs.close();
		pst.close();

		return flag;
	}

	public static void insertTempList(String contentUrl) throws Exception {
		String sql = "INSERT INTO temp_list (content_url,load_flag) VALUES (?,0)";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, contentUrl);
		pst.executeUpdate();
		pst.close();
	}

}
