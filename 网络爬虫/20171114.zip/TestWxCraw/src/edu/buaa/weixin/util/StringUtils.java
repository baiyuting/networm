package edu.buaa.weixin.util;

public class StringUtils {

	/**
	 * 将字符串中所有HTML的转义字符内容替换为合法的内容
	 * @param input
	 * @return
	 */
	public static String replaceHTMLChar(String input) {
		return input.replace("&quot;", "\"").replace("\\\\/", "/").replace("&amp;amp;", "&");
	}
	
}
