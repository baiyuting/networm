package edu.buaa.weixin.craw;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import edu.buaa.weixin.util.DBUtils;
import edu.buaa.weixin.util.StringUtils;
import edu.buaa.weixin.vo.Article;

@WebServlet("/DataListServlet")
public class DataListServlet extends HttpServlet {
	public DataListServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 尝试接收提交过来的数据，并打印，看是否正确接收到了数据
		// 通过request.getParameter()方法来接收传递过来的参数
		// node.js服务器中传递了两个参数，一个是url，另一个是str
		String url = URLDecoder.decode(request.getParameter("url"));
		String str = URLDecoder.decode(request.getParameter("str"),"UTF-8");

		// 通过字符串操作，来替换掉转义的字符
		str = StringUtils.replaceHTMLChar(str);

		// 对这个字符串进行JSON转化处理
		JSONArray array = JSON.parseObject(str).getJSONArray("list");
		
		// 先要对整个公众号来进行判断和保存。
		// 需要先提取出biz的值，这个值就在url里
		// 先通过?来截取出所有的参数
		String params = url.substring(url.indexOf("?") + 1);
		// 再按照 & 来拆分
		String[] allParams = params.split("&");
		
		String bizid = null;
		// 再按照 ＝ 来拆分
		for (String p : allParams) {
			String key = p.substring(0,p.indexOf("="));
			String value = p.substring(p.indexOf("=") + 1);
			// 判断是否是 __biz这个参数
			if (key.equals("__biz")) {
				bizid = value;
				break;
			}
		}
		
		try {
			DBUtils.insertWeixin(bizid);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		// 分别取得每一个对象中的各种属性
		for (int i = 0; i < array.size(); i++) {
			JSONObject obj = array.getJSONObject(i);
			// 取得里面的两个子对象
			JSONObject commMsg = obj.getJSONObject("comm_msg_info");
			JSONObject appExtMsg = obj.getJSONObject("app_msg_ext_info");

			try {
				// 取得日期
				long datetime = commMsg.getLongValue("datetime") * 1000;
				// 取得消息类型
				int type = commMsg.getIntValue("type");
				if (type == 49) {

					// 取得其他需要的属性
					String title = appExtMsg.getString("title");
					String digest = appExtMsg.getString("digest");
					String contentUrl = appExtMsg.getString("content_url");
					String sourceUrl = appExtMsg.getString("source_url");
					String cover = appExtMsg.getString("cover");
					String author = appExtMsg.getString("author");
					int isMulti = appExtMsg.getIntValue("is_multi");
					
					Article a = new Article();
					a.setBiz(bizid);
					a.setTitle(title);
					a.setDigest(digest);
					a.setContentUrl(contentUrl);
					a.setSourceUrl(sourceUrl);
					a.setCover(cover);
					a.setIsMulti(isMulti);
					a.setAuthor(author);
					a.setPubDate(new Date(datetime));
					
					if (!DBUtils.insertArticle(a)) {
						// 如果这条数据没有被保存过，说明内容也没有被提取过
						// 就需要把这个url也保存到temp_list表中，便于后面单独提取这个具体的内容和点赞数量等信息。
						DBUtils.insertTempList(contentUrl);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

}
