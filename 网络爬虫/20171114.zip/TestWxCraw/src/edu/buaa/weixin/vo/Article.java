package edu.buaa.weixin.vo;

import java.util.Date;

public class Article {

	private Integer id;
	private String title;
	private String digest;
	private String contentUrl;
	private String sourceUrl;
	private String cover;
	private Date pubDate;
	private Integer readNum;
	private Integer likeNum;
	private Integer isMulti;
	private String author;
	private String biz;

	public Article() {
		super();
	}

	public Article(Integer id, String title, String digest, String contentUrl,
			String sourceUrl, String cover, Date pubDate, Integer readNum,
			Integer likeNum, Integer isMulti, String author) {
		super();
		this.id = id;
		this.title = title;
		this.digest = digest;
		this.contentUrl = contentUrl;
		this.sourceUrl = sourceUrl;
		this.cover = cover;
		this.pubDate = pubDate;
		this.readNum = readNum;
		this.likeNum = likeNum;
		this.isMulti = isMulti;
		this.author = author;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDigest() {
		return digest;
	}

	public void setDigest(String digest) {
		this.digest = digest;
	}

	public String getContentUrl() {
		return contentUrl;
	}

	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}

	public String getSourceUrl() {
		return sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getCover() {
		return cover;
	}

	public void setCover(String cover) {
		this.cover = cover;
	}

	public Date getPubDate() {
		return pubDate;
	}

	public void setPubDate(Date pubDate) {
		this.pubDate = pubDate;
	}

	public Integer getReadNum() {
		return readNum;
	}

	public void setReadNum(Integer readNum) {
		this.readNum = readNum;
	}

	public Integer getLikeNum() {
		return likeNum;
	}

	public void setLikeNum(Integer likeNum) {
		this.likeNum = likeNum;
	}

	public Integer getIsMulti() {
		return isMulti;
	}

	public void setIsMulti(Integer isMulti) {
		this.isMulti = isMulti;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getBiz() {
		return biz;
	}

	public void setBiz(String biz) {
		this.biz = biz;
	}

	@Override
	public String toString() {
		return "Article [id=" + id + ", title=" + title + ", digest=" + digest
				+ ", contentUrl=" + contentUrl + ", sourceUrl=" + sourceUrl
				+ ", cover=" + cover + ", pubDate=" + pubDate + ", readNum="
				+ readNum + ", likeNum=" + likeNum + ", isMulti=" + isMulti
				+ ", author=" + author + "]";
	}

}
