package edu.buaa.weixin.craw;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import edu.buaa.weixin.util.DBUtils;

@WebServlet("/ContinueCrawServlet")
public class ContinueCrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 接收提交过来的具体数据
		String str = request.getParameter("str");
		String url = request.getParameter("url");

		// 需要进行转码，如果不是mac系统，就需要明确编码是UTF-8
		str = URLDecoder.decode(str, "UTF-8");
		url = URLDecoder.decode(url, "UTF-8");

		Document doc = Jsoup.parse(str);
		// 首先解析出标题信息
		Element titleEl = doc.getElementsByTag("h2").get(0);
		String title = titleEl.text();
		// 定位所有内容信息，这里先使用最简单的方式，读取所有的span中的内容
		// Elements allSpans = doc.getElementsByTag("span");
		// // System.out.println(allSpans.size() + " =========  ");
		// for (Element spanEl : allSpans) {
		// String content = spanEl.text();
		// System.out.println(content);
		// }

		// 先定位section，然后通过section再找里面的p和里面的span
		Elements sections = doc.getElementsByAttributeValue("powered-by",
				"xiumi.us");
		String content = null;
		for (Element sectionEl : sections) {
			int size = sectionEl.getElementsByTag("span").size();
			if (size > 0) {
				content = sectionEl.text();
				break;
			}
		}
		System.out.println(content);

		// 根据url地址，找到里面的sn号，作为文件名进行保存，方便进行数据的提取。
		String allParams = url.substring(url.indexOf("?") + 1);
		String[] params = allParams.split("&");
		String fileName = null;
		for (String paramTemp : params) {
			// 根据等号区分参数名和参数值
			String key = paramTemp.substring(0, paramTemp.indexOf("="));
			String value = paramTemp.substring(paramTemp.indexOf("=") + 1);

			if (key.equals("sn")) {
				fileName = value + ".txt";
				break;
			}
		}

		// 分别保存标题和内容
		PrintWriter writer = new PrintWriter(new File(
				"/Users/kkb/Documents/weixin_data/" + fileName));
		writer.println(title);
		writer.print(content);
		writer.close();

		// 将load_flag值设置为1
		try {
			DBUtils.updateTempListFlag(url);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 准备一个自动切换的新的URL地址
		String newUrl = null;
		try {
			newUrl = DBUtils.getNewContentUrl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (newUrl == null) {
			// 已经没有等待提取的url地址了，需要从列表页重新获取新的地址
			// 自己拼接一个列表页地址出来。
			// 从weixin表中找到一个最新的biz，提取出来，然后拼接进去。
			String biz = null;
			try {
				biz = DBUtils.getOldBizid();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (biz != null) {
				newUrl = "http://mp.weixin.qq.com/mp/profile_ext?action=home&__biz="
						+ biz + "&scene=124";
			}
		}

		if (newUrl != null) {
			// 返回结果给AnyProxy服务器
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.print("<script type='text/javascript'>");
			out.print("window.setTimeout(function(){"
					+ "window.location.href='" + newUrl + "';},2000);");
			out.print("</script>");
			out.close();
		}

	}

}
