package edu.buaa.weixin.craw;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import edu.buaa.weixin.util.DBUtils;

@WebServlet("/DataExtServlet")
public class DataExtServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 接收提交过来的具体数据
		String str = request.getParameter("str");
		String url = request.getParameter("url");

		// 需要进行转码，如果不是mac系统，就需要明确编码是UTF-8
		str = URLDecoder.decode(str, "UTF-8");
		url = URLDecoder.decode(url, "UTF-8");

		String allParams = url.substring(url.indexOf("?") + 1);
		String[] params = allParams.split("&");
		String sn = null;
		for (String paramTemp : params) {
			// 根据等号区分参数名和参数值
			String key = paramTemp.substring(0, paramTemp.indexOf("="));
			String value = paramTemp.substring(paramTemp.indexOf("=") + 1);

			if (key.equals("sn")) {
				sn = value;
				break;
			}
		}

		// 取得read_num和 like_num的值
		JSONObject obj = JSON.parseObject(str);
		JSONObject appMsgStat = obj.getJSONObject("appmsgstat");
		int readNum = appMsgStat.getIntValue("read_num");
		int likeNum = appMsgStat.getIntValue("like_num");

		// 更新数据库中article的数据，并删除temp_list中对应的数据
		try {
			DBUtils.updateReadLikeNum(readNum, likeNum, sn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 准备一个自动切换的新的URL地址
		String newUrl = null;
		try {
			newUrl = DBUtils.getNewContentUrl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (newUrl == null) {
			// 已经没有等待提取的url地址了，需要从列表页重新获取新的地址
			// 自己拼接一个列表页地址出来。
			// 从weixin表中找到一个最新的biz，提取出来，然后拼接进去。
			String biz = null;
			try {
				biz = DBUtils.getOldBizid();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (biz != null) {
				newUrl = "http://mp.weixin.qq.com/mp/profile_ext?action=home&__biz="
						+ biz + "&scene=124";
			}
		}

		if (newUrl != null) {
			// 返回结果给AnyProxy服务器
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.print("<script type='text/javascript'>");
			out.print("window.setTimeout(function(){"
					+ "window.location.href='" + newUrl + "';},2000);");
			out.print("</script>");
			out.close();;
		}
	}

}
