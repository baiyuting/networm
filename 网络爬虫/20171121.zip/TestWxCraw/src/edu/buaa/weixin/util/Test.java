package edu.buaa.weixin.util;

import java.util.Date;

public class Test {

	public static void main(String[] args) {
		long value = 1510631398 * 1000l;
//		System.out.println(value);
		Date d = new Date(value);
		System.out.println(d);
		
	}

}
