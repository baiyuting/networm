package edu.buaa.weixin.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import edu.buaa.weixin.vo.Article;

public class DBUtils {

	private static Connection conn;

	static {
		try {
			// 初始化数据库连接对象
			Class.forName("org.gjt.mm.mysql.Driver");
			// 根据数据库的位置和用户名密码，来链接数据库
			// 注意 Connection 的包 使用 java.sql.包
			conn = DriverManager
					.getConnection(
							"jdbc:mysql://localhost:3306/wxdata?useUnicode=true&characterEncoding=UTF-8",
							"root", "root");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 保存公众号数据的方法
	public static void insertWeixin(String bizid) throws Exception {
		// 先要判断这个公众号是否被抓去过，在weixin表中是否已经有了这条数据
		String sql = "SELECT id FROM weixin WHERE biz = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, bizid);
		ResultSet rs = pst.executeQuery();
		if (!rs.next()) {
			// 数据库中没有这条数据，需要进行保存操作
			sql = "INSERT INTO weixin (biz,get_date) VALUES (?,?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, bizid);
			// 设置当前的系统时间
			pst.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
			pst.executeUpdate();

		}
		rs.close();
		pst.close();
	}

	/**
	 * 保存文章的方法，
	 * 
	 * @param article
	 *            文章对象
	 * @return 是否有重复的内容
	 * @throws Exception
	 */
	public static boolean insertArticle(Article article) throws Exception {
		// 先从数据库里查询一下数据库中到底有没有这条数据
		String sql = "SELECT id FROM article WHERE content_url = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, article.getContentUrl());
		// 取得结果，判断是否有重复数据
		boolean flag = true;
		ResultSet rs = pst.executeQuery();
		if (!rs.next()) {
			flag = false;
			// 没有重复
			// 需要进行数据的保存
			sql = "INSERT INTO article (biz,title,digest,pub_date,content_url,source_url,"
					+ "cover,is_multi,author) VALUES (?,?,?,?,?,?,?,?,?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, article.getBiz());
			pst.setString(2, article.getTitle());
			pst.setString(3, article.getDigest());
			pst.setTimestamp(4, new Timestamp(article.getPubDate().getTime()));
			pst.setString(5, article.getContentUrl());
			pst.setString(6, article.getSourceUrl());
			pst.setString(7, article.getCover());
			pst.setInt(8, article.getIsMulti());
			pst.setString(9, article.getAuthor());
			pst.executeUpdate();
		}
		rs.close();
		pst.close();

		return flag;
	}

	/**
	 * 保存爬取队列表的数据
	 * 
	 * @param contentUrl
	 * @throws Exception
	 */
	public static void insertTempList(String contentUrl) throws Exception {
		String sql = "INSERT INTO temp_list (content_url,load_flag) VALUES (?,0)";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, contentUrl);
		pst.executeUpdate();
		pst.close();
	}

	/**
	 * 标识标志位为已经读取内容的状态
	 * 
	 * @param contentUrl
	 * @throws Exception
	 */
	public static void updateTempListFlag(String contentUrl) throws Exception {
		String sql = "UPDATE temp_list SET load_flag=1 WHERE content_url = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, contentUrl);
		pst.executeUpdate();
		pst.close();
	}

	/**
	 * 更新阅读数和点赞数，并删除队列表中的这条数据
	 * 
	 * @param readNum
	 * @param likeNum
	 * @param sn
	 * @throws Exception
	 */
	public static void updateReadLikeNum(int readNum, int likeNum, String sn)
			throws Exception {
		String sql = "UPDATE article SET readNum = ? , likeNum = ? WHERE content_url LIKE ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setInt(1, readNum);
		pst.setInt(2, likeNum);
		// 这里模糊查询的条件需要自己拼接
		pst.setString(3, "%sn=" + sn + "%");
		pst.executeUpdate();

		// 删除temp_list表数据
		sql = "DELETE FROM temp_list WHERE content_url LIKE ?";
		pst = conn.prepareStatement(sql);
		pst.setString(1, "%sn=" + sn + "%");
		pst.executeUpdate();
		
		pst.close();

	}
	
	/**
	 * 读取队列中的最新的url
	 * @return 最新的待处理的url地址
	 * @throws Exception 
	 */
	public static String getNewContentUrl() throws Exception {
		String sql = "SELECT content_url FROM temp_list WHERE load_flag = 0 ORDER BY id LIMIT 0,1" ;
		PreparedStatement pst = conn.prepareStatement(sql);
		ResultSet rs= pst.executeQuery();
		String contentUrl = null;
		if (rs.next()) {
			contentUrl = rs.getString(1);
		}
		rs.close();
		pst.close();
		return contentUrl;
	}
	
	/**
	 * 取得距离现在最长时间没有被爬取的公众号bizid，根据这个id来继续爬取。
	 * @return
	 * @throws Exception 
	 */
	public static String getOldBizid() throws Exception {
		String sql = "SELECT biz FROM weixin WHERE datediff(now(),get_date) > 0 ORDER BY get_date LIMIT 0,1" ;
		PreparedStatement pst = conn.prepareStatement(sql);
		ResultSet rs= pst.executeQuery();
		
		String biz = null;
		if (rs.next()) {
			biz = rs.getString(1);
			// 如果没有问题，能够取得biz，说明这个公众号马上就要被爬取了，所以把它的爬取时间修改为当前时间 
			sql = "UPDATE weixin SET get_date = now() WHERE biz = ?" ;
			pst = conn.prepareStatement(sql);
			pst.setString(1, biz);
			pst.executeUpdate();
		}
		rs.close();
		pst.close();
		
		
		return biz;
	}

}
