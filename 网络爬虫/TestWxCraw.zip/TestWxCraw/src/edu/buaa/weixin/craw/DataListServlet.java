package edu.buaa.weixin.craw;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DataListServlet")
public class DataListServlet extends HttpServlet {
	public DataListServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 尝试接收提交过来的数据，并打印，看是否正确接收到了数据
		// 通过request.getParameter()方法来接收传递过来的参数
		// node.js服务器中传递了两个参数，一个是url，另一个是str
		String url = URLDecoder.decode(request.getParameter("url"));
		String str = URLDecoder.decode(request.getParameter("str"));
		
		System.out.println(url + " +++++++++ ");
		System.out.println(str + " ==========");
	}

}
