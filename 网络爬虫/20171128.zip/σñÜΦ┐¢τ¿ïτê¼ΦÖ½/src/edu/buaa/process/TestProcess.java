package edu.buaa.process;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TestProcess {

	// 准备一个数据库连接对象，用来在对列表中提取数据库连接
	private static Connection conn;

	private static final String SAVE_PATH = "/Users/kkb/Documents/慧科－New/授课/201709北航硕士网络爬虫/20171128/data/";

	static {
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_process", "root", "root");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {
		// 需要写一个死循环
		while (true) {
			// 提取一个连接地址
			ProcessUrl pu = getNewUrl();
			if (pu == null) {
				Thread.sleep(2000);
			} else {
				crawData(pu.getUrl(),pu.getDepth());
			}
		}
	}

	public static void crawData(String url, int depth) throws Exception {
		Document doc = Jsoup.connect(url).get();
		// 提取里面所有的超链接，以便继续进行队列的扩充
		Elements allALink = doc.getElementsByTag("a");
		for (Element aLink : allALink) {
			String href = aLink.attr("href");
			// 判断连接是否合法
			if (href.startsWith("http://") || href.startsWith("https://")) {
				// 在表中判断，是否有连接地址已经被爬取或等待爬取。
				if (!checkUrl(href)) {
					// 需要把连接加入到数据表中
					insertUrl(href, depth + 1);
				}
			}
		}

		// 提取数据，这里提取的是163的数据内容
		if (url.matches(".*/\\d{2}/\\d{4}/\\d{2}/[A-Z0-9]+\\.html")) {
			String title = doc.title();
			String content = doc.getElementById("endText").text();

			String fileName = System.currentTimeMillis() + ".txt";
			PrintWriter writer = new PrintWriter(SAVE_PATH + fileName);
			writer.println(title);
			writer.println(content);
			writer.print(url);
			writer.close();
		}

		// 当数据处理完成后，就直接结束即可，在主方法中通过死循环来完成所有内容的爬取。

	}

	private static ProcessUrl getNewUrl() throws Exception {
		conn.setAutoCommit(false);
		String sql = "SELECT url,depth FROM tb_process WHERE over_flag = 0 ORDER BY depth,id LIMIT 0,1";
		PreparedStatement pst = conn.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		ProcessUrl pu = null;
		if (rs.next()) {
			pu = new ProcessUrl(rs.getString(1), rs.getInt(2));
			// 需要修改这条数据的over_flag值
			sql = "UPDATE tb_process SET over_flag = 1 WHERE url = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, pu.getUrl());
			pst.executeUpdate();
		}
		conn.commit();
		conn.setAutoCommit(true);
		rs.close();
		pst.close();
		return pu;
	}

	private static void insertUrl(String url, int depth) throws Exception {
		String sql = "INSERT INTO tb_process (url,over_flag,depth) VALUES (?,0,?)";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, url);
		pst.setInt(2, depth);
		pst.executeUpdate();
		pst.close();
	}

	private static boolean checkUrl(String url) throws Exception {
		String sql = "SELECT * FROM tb_process WHERE url = ?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, url);
		ResultSet rs = pst.executeQuery();
		boolean flag = rs.next();
		rs.close();
		pst.close();
		return flag;
	}

}
