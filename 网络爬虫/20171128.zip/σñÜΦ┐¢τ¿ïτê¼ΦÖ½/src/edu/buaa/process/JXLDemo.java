package edu.buaa.process;

import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class JXLDemo {

	public static void main(String[] args) throws Exception {
		// WritableWorkbook wb = Workbook
		// .createWorkbook(new
		// File("/Users/kkb/Documents/慧科－New/授课/201709北航硕士网络爬虫/20171128/test.xls"));
		// WritableSheet sheet = wb.createSheet("表1", 0);
		// sheet.addCell(new Label( 0, 1,"测试表内容"));
		// wb.write();
		// wb.close();

		Workbook wb = Workbook.getWorkbook(new File("/Users/kkb/Documents/慧科－New/授课/201709北航硕士网络爬虫/20171128/test.xls"));
		Sheet sheet = wb.getSheet(0);
		for (int i = 0;i < sheet.getRows();i++) {
			System.out.println(sheet.getCell(0, i).getContents());
		}
	}

}
